from __future__ import annotations

import torch

from src.config.settings import Settings
from src.models.cnn import (
    AlexNet,
    LeNet5,
    ResNet,
    _Bottleneck,
    get_model,
    resnet18,
    resnet34,
    resnet50,
)


def _make_settings(**overrides: object) -> Settings:
    defaults: dict[str, object] = {
        "image_size": 224,
        "in_channels": 1,
        "num_classes": 8,
        "device": "cpu",
    }
    defaults.update(overrides)
    return Settings.model_validate(defaults)


def test_lenet5_forward_shape() -> None:
    """LeNet-5 produces (batch, num_classes) output."""
    s = _make_settings()
    model = LeNet5(s)
    x = torch.randn(2, 1, 224, 224)
    out = model(x)
    assert out.shape == (2, 8)


def test_alexnet_forward_shape() -> None:
    """AlexNet produces (batch, num_classes) output."""
    s = _make_settings()
    model = AlexNet(s)
    x = torch.randn(2, 1, 224, 224)
    out = model(x)
    assert out.shape == (2, 8)


def test_resnet18_forward_shape() -> None:
    """ResNet-18 produces (batch, num_classes) output."""
    s = _make_settings()
    model = resnet18(s)
    x = torch.randn(2, 1, 224, 224)
    out = model(x)
    assert out.shape == (2, 8)


def test_resnet34_forward_shape() -> None:
    """ResNet-34 produces (batch, num_classes) output."""
    s = _make_settings()
    model = resnet34(s)
    x = torch.randn(2, 1, 224, 224)
    out = model(x)
    assert out.shape == (2, 8)


def test_resnet50_forward_shape() -> None:
    """ResNet-50 produces (batch, num_classes) output."""
    s = _make_settings(model_name="resnet50")
    model = resnet50(s)
    out = model(torch.randn(2, 1, 224, 224))
    assert out.shape == (2, 8)


def test_resnet50_uses_bottleneck() -> None:
    """ResNet-50 is built from Bottleneck blocks (expansion 4)."""
    model = resnet50(_make_settings(model_name="resnet50"))
    assert model.block is _Bottleneck
    assert isinstance(model.layer1[0], _Bottleneck)


def test_get_model_factory() -> None:
    """get_model dispatches correctly for each registered name."""
    for name, cls in [
        ("lenet5", LeNet5),
        ("alexnet", AlexNet),
        ("resnet18", ResNet),
        ("resnet34", ResNet),
        ("resnet50", ResNet),
    ]:
        s = _make_settings(model_name=name)
        model = get_model(s)
        assert isinstance(model, cls)


def test_models_accept_3_channels() -> None:
    """Models can be instantiated with 3 input channels (for bias part)."""
    s = _make_settings(in_channels=3)
    for name in ("lenet5", "alexnet", "resnet18", "resnet34"):
        s_copy = s.model_copy(update={"model_name": name})
        model = get_model(s_copy)
        x = torch.randn(2, 3, 224, 224)
        out = model(x)
        assert out.shape == (2, 8)


def test_resnet18_has_residual_connections() -> None:
    """Verify that ResNet-18 has shortcut connections in its blocks."""
    s = _make_settings(model_name="resnet18")
    model = resnet18(s)
    # Each BasicBlock should have a forward that adds identity
    block = model.layer1[0]
    assert hasattr(block, "downsample") or hasattr(block, "conv1")
